package com.example.household;
import android.content.*; import android.database.*; import android.database.sqlite.*; import java.util.*;

public class DB extends SQLiteOpenHelper {
 DB(Context c){super(c,"households.db",null,1);}
 public void onCreate(SQLiteDatabase d){
  d.execSQL("CREATE TABLE families(id INTEGER PRIMARY KEY AUTOINCREMENT, head TEXT, national TEXT, phone TEXT, location TEXT)");
  d.execSQL("CREATE TABLE members(id INTEGER PRIMARY KEY AUTOINCREMENT, family_id INTEGER, name TEXT, national TEXT, gender TEXT, birth TEXT, relation TEXT, education TEXT, job TEXT)");
  d.execSQL("CREATE INDEX idx_m_national ON members(national)");
  d.execSQL("CREATE INDEX idx_m_gender ON members(gender)");
  d.execSQL("CREATE INDEX idx_m_education ON members(education)");
  d.execSQL("CREATE INDEX idx_m_birth ON members(birth)");
 }
 public void onUpgrade(SQLiteDatabase d,int o,int n){}
 long family(String h,String n,String p,String l){ContentValues v=new ContentValues();v.put("head",h);v.put("national",n);v.put("phone",p);v.put("location",l);return getWritableDatabase().insert("families",null,v);}
 long lastFamily(){Cursor c=getReadableDatabase().rawQuery("SELECT id FROM families ORDER BY id DESC LIMIT 1",null);long x=0;if(c.moveToFirst())x=c.getLong(0);c.close();return x;}
 void member(long fid,String[] a){ContentValues v=new ContentValues();v.put("family_id",fid);String[] k={"name","national","gender","birth","relation","education","job"};for(int i=0;i<7;i++)v.put(k[i],a[i]);getWritableDatabase().insert("members",null,v);}
 int count(String t){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+t,null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
 ArrayList<String> search(String q,String gender,String education,String minBirth,String maxBirth){
  ArrayList<String> r=new ArrayList<>();StringBuilder s=new StringBuilder("SELECT name,national,gender,birth,relation,education,job FROM members WHERE 1=1");ArrayList<String>a=new ArrayList<>();
  if(!q.trim().isEmpty()){s.append(" AND (name LIKE ? OR national LIKE ? OR job LIKE ? OR education LIKE ?)");String x="%"+q+"%";for(int i=0;i<4;i++)a.add(x);}
  if(!gender.equals("همه")){s.append(" AND gender=?");a.add(gender);}
  if(!education.equals("همه")){s.append(" AND education=?");a.add(education);}
  if(!minBirth.isEmpty()){s.append(" AND birth>=?");a.add(minBirth);}
  if(!maxBirth.isEmpty()){s.append(" AND birth<=?");a.add(maxBirth);}
  s.append(" ORDER BY name");
  Cursor c=getReadableDatabase().rawQuery(s.toString(),a.toArray(new String[0]));
  while(c.moveToNext())r.add("نام: "+c.getString(0)+"\nکد ملی: "+c.getString(1)+"\nجنسیت: "+c.getString(2)+"\nتولد: "+c.getString(3)+"\nنسبت: "+c.getString(4)+"\nتحصیل: "+c.getString(5)+"\nشغل: "+c.getString(6));c.close();return r;
 }
}