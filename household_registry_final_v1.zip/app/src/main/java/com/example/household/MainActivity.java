package com.example.household;
import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity{
 DB db; LinearLayout box;
 public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);home();}
 TextView title(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(24);t.setTextColor(Color.DKGRAY);t.setGravity(17);t.setPadding(8,20,8,20);return t;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setAllCaps(false);return b;}
 EditText f(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(16);box.addView(e);return e;}
 void home(){box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,20,24,20);box.addView(title("سامانه ثبت اطلاعات خانوار"));
  box.addView(btn("➕ ثبت خانوار جدید"));box.addView(btn("🔎 جست‌وجوی هوشمند"));box.addView(btn("📊 گزارش آماری"));box.addView(btn("💾 پشتیبان‌گیری"));
  Button a=(Button)box.getChildAt(1),s=(Button)box.getChildAt(2),st=(Button)box.getChildAt(3),bk=(Button)box.getChildAt(4);
  a.setOnClickListener(v->addFamily());s.setOnClickListener(v->search());st.setOnClickListener(v->stats());bk.setOnClickListener(v->Toast.makeText(this,"پشتیبان‌گیری امن در نسخه انتشار به فایل دستگاه متصل می‌شود.",Toast.LENGTH_LONG).show());setContentView(box);}
 void addFamily(){box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,20,24,20);box.addView(title("ثبت خانوار"));
  EditText loc=f("استان / شهرستان / شهر / روستا / محله"),head=f("نام و نام خانوادگی سرپرست"),nat=f("کد ملی سرپرست"),phone=f("شماره موبایل");
  Button save=btn("💾 ذخیره خانوار"),mem=btn("➕ افزودن عضو"),back=btn("↩ بازگشت");box.addView(save);box.addView(mem);box.addView(back);setContentView(box);
  save.setOnClickListener(v->{if(head.getText().toString().trim().isEmpty()){toast("نام سرپرست الزامی است");return;}long id=db.family(head.getText().toString(),nat.getText().toString(),phone.getText().toString(),loc.getText().toString());toast("خانوار ذخیره شد. شناسه: "+id);});
  mem.setOnClickListener(v->memberDialog());back.setOnClickListener(v->home());
 }
 void memberDialog(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);String[] h={"نام و نام خانوادگی","کد ملی","جنسیت: پسر / دختر","تاریخ تولد YYYY-MM-DD","نسبت با سرپرست","تحصیل: دانش‌آموز / دانشجو / فارغ‌التحصیل / بدون تحصیل","شغل"};EditText[] e=new EditText[7];for(int i=0;i<7;i++){e[i]=new EditText(this);e[i].setHint(h[i]);l.addView(e[i]);}
  new AlertDialog.Builder(this).setTitle("افزودن عضو").setView(l).setPositiveButton("ذخیره",(d,w)->{long id=db.lastFamily();if(id>0){String[] a=new String[7];for(int i=0;i<7;i++)a[i]=e[i].getText().toString();db.member(id,a);toast("عضو ذخیره شد");}}).setNegativeButton("لغو",null).show();}
 void search(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText q=new EditText(this);q.setHint("نام، کد ملی یا شغل");Spinner g=new Spinner(this);g.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"همه","پسر","دختر"}));Spinner ed=new Spinner(this);ed.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"همه","دانش‌آموز","دانشجو","فارغ‌التحصیل","بدون تحصیل"}));EditText min=fake(l,"تولد از YYYY-MM-DD"),max=fake(l,"تولد تا YYYY-MM-DD");l.addView(q,0);l.addView(g,1);l.addView(ed,2);
  new AlertDialog.Builder(this).setTitle("جست‌وجوی هوشمند").setView(l).setPositiveButton("جست‌وجو",(d,w)->show(db.search(q.getText().toString(),g.getSelectedItem().toString(),ed.getSelectedItem().toString(),min.getText().toString(),max.getText().toString()))).setNegativeButton("لغو",null).show();}
 EditText fake(LinearLayout l,String h){EditText e=new EditText(this);e.setHint(h);l.addView(e);return e;}
 void show(ArrayList<String> r){StringBuilder s=new StringBuilder();for(String x:r)s.append(x).append("\n\n");if(r.isEmpty())s.append("نتیجه‌ای پیدا نشد.");new AlertDialog.Builder(this).setTitle("نتایج: "+r.size()).setMessage(s).setPositiveButton("باشه",null).show();}
 void stats(){new AlertDialog.Builder(this).setTitle("گزارش آماری").setMessage("تعداد خانوار: "+db.count("families")+"\nتعداد اعضا: "+db.count("members")).setPositiveButton("باشه",null).show();}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}